<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
      <?php if(auth()->user()->role == 'admin'): ?>
      <li class="nav-item"><a class="nav-link <?php echo e(($active =="dashboard") ? 'active' : ''); ?>" aria-current="page" href="/dashboard"><i class="fas fa-home"></i> Dashboard</a></li>
      <?php elseif(auth()->user()->role == 'patient'): ?>
      <li class="nav-item"><a class="nav-link <?php echo e(($active =="dashboard") ? 'active' : ''); ?>" aria-current="page" href="/dashboard_p"><i class="fas fa-home"></i> Dashboard</a></li>
      <?php endif; ?>
    </ul>

    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
      <span>Manage</span>
      <a class="link-secondary" href="#" aria-label="Add a new report">
        <span data-feather="plus-circle"></span>
      </a>
    </h6>
    <ul class="nav flex-column mb-auto ">
      <?php if(auth()->user()->role == 'admin'): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(($active =="batch") ? 'active' : ''); ?>" href="/batch">
          <i class="far fa-list-alt"></i>
           Vaccine Batch information
        </a>
      </li>
      <?php else: ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(($active =="vaccination") ? 'active' : ''); ?>" href="/vaccination">
          <i class="far fa-list-alt"></i>
           Vaccination 
        </a>
      </li>
      <?php endif; ?>
    </ul>
    <hr>
    <ul class="nav flex-column mb-2">
      <li class="nav-item">
        <a href="/logout" class="nav-link px-3"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </li>
    </ul>
  </div>

</nav>
<?php /**PATH F:\Kerja\SE RAM\PCVS\resources\views/layouts/includes/_sidebar.blade.php ENDPATH**/ ?>