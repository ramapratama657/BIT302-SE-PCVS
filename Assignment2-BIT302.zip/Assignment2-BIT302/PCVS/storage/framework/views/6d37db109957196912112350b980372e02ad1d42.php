

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class=" justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom text-center">
            <h2>Vaccine Batch </h2>
            <small > <strong><?php echo e($centre->centreName); ?></strong>, <?php echo e($centre->address); ?></small>
        </div>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success fade show" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php $__errorArgs = ['centreId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger fade show" role="alert">
                <?php echo e($message); ?>

              </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['batchNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger fade show" role="alert">
            <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['vaccineId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger fade show" role="alert">
            <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['quantityAvailable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger fade show" role="alert">
            <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['expiryDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger fade show" role="alert">
            <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="table-responsive">
            <caption>List of Vaccionation Appointment</caption><br><br>
            
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Appointment ID</th>                    
                    <th scope="col">Patient IC</th>                    
                    <th scope="col">Patient Name</th>                    
                    <th scope="col">Batch Number</th>                    
                    <th scope="col">Vaccine Name</th>
                    <th scope="col">Appointment Date</th>                    
                    <th scope="col">Expire Date</th>
                    <th scope="col">Doses Available</th>
                    <th scope="col">Status </th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $vaccination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($patient->find($item->patientId)->ic); ?></td>
                        <td><?php echo e($patient->find($item->patientId)->name); ?></td>
                        <td><?php echo e($data_batch->find($item->batchId)->batchNo); ?></td>
                        <td><?php echo e($data_batch->find($item->batchId)->vaccineId); ?></td>
                        <td><?php echo e($item->appointmentDate); ?></td>
                        <td><?php echo e($data_batch->find($item->batchId)->expiryDate); ?></td>
                        <td><?php echo e($data_batch->find($item->batchId)->quantityAvailable); ?></td>
                        <td><?php echo e($item->status); ?></td>

                        <td><a href="" class="btn btn-success btn-sm">Confirm</a> <a href="" class="btn btn-danger btn-sm">Reject</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
          </div>
          
        </main>
    </div>
</div>

 <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Record new vaccine batch</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form action="/addBatch" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                <label for="vaccine" class="form-label">Select Vaccine</label>
                <select class="form-select <?php $__errorArgs = ['vaccine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Default select example" name="vaccineId" >
                        <option selected value="">Select the vaccine</option>
                        <?php $__currentLoopData = $vaccine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaccines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vaccines->id); ?>"><?php echo e($vaccines->name); ?>, <?php echo e($vaccines->manufacture); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                <div class="mb-3">
                    <label for="batchNo
                    batchNo" class="form-label">Bacth Number</label>
                    <input type="number" class="form-control" id="batchNo" name="batchNo" >
                </div>
                <div class="mb-3">
                    <label for="expiryDate" class="form-label">Expiry Date</label>
                    <input type="date" class="form-control" id="expiryDate" name="expiryDate" >
                </div>
                <div class="mb-3">
                    <label for="quantityAvailable" class="form-label">Quantity of doses available </label>
                    <input type="number" class="form-control" id="quantityAvailable" name="quantityAvailable" >
                </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" type="submit">Save changes</button>
            </div>
            </form>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kerja\SE RAM\PCVS\resources\views/vaccination/index_admin.blade.php ENDPATH**/ ?>