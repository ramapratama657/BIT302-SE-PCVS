
<script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js"></script>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class=" justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom text-center">
            <h2>Vaccine Batch </h2>
            
        </div>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success fade show" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php $__errorArgs = ['appointmentDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger fade show" role="alert">
                <?php echo e($message); ?>

              </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form action="/vaccination">
                        <div class="input-group mb-3">
                            <select class="form-select" name="search" onchange="javascript:this.form.submit()">
                                <option selected value="" disabled>Select the vaccine</option>
                                <?php $__currentLoopData = $vaccine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaccines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($vaccines->id); ?>" <?php echo e(($id == $vaccines->id) ? 'selected' : ''); ?>><?php echo e($vaccines->name); ?>, <?php echo e($vaccines->manufacture); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="d-grid gap-2 col-6 mx-auto mb-2">
                <a class="btn btn-secondary btn-sm mx-auto" href="/vaccination">Show all</a>
            </div>
            <br>
            <div class="row">
            <?php $__currentLoopData = $batch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="card" style="width: 100%;">
                        <img src="/img/vaccine1.jpg" class="card-img-top" alt="vaccine">
                        <div class="card-body">
                            <h5 class="card-title text-center"><?php echo e($vaccine->find($item->vaccineId)->name); ?> (<?php echo e($item->batchNo); ?>)</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"><?php echo e($centre->find($item->centreId)->centreName); ?>, <?php echo e($centre->find($item->centreId)->address); ?></li>
                                <li class="list-group-item">Batch No : <?php echo e($item->batchNo); ?></li>
                                <li class="list-group-item">Quantity Available: <?php echo e($item->quantityAvailable); ?></li>
                                <li class="list-group-item"><small class="text-muted">Expiry date: <?php echo e($item->expiryDate); ?></small></li>
                            </ul>
                             <div class="d-grid gap-2">
                                <button type="button" class="btn btn-primary btn-sm user_dialog" data-id="<?php echo e($item->id); ?>" data-centre="<?php echo e($centre->find($item->centreId)->centreName); ?>" data-expiry=" <?php echo e($item->expiryDate); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal">Request Appointment</button>
                             </div>
                        </div>
                    </div>
                </div>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>    
            <div class="text-right mt-4">
                Total Data : <?php echo e($batch->total()); ?> <br/>
                Data shown per page : <?php echo e($batch->perPage()); ?> <br/>
            </div>    
        </div>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($batch->links()); ?>

        </div>
        
    </main>
</div>
</div>
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Request Appointment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="/appointment" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="mb-3">
                <label for="centre">Health Centre Name</label>
                <input type="text" class="form-control" id="centre" name="centre" value="" disabled>
            </div>
            <input type="hidden" class="form-control" id="batchId" name="batchId" value="">
            <div class="mb-3">
              <label for="appointmentDate" class="form-label">Appoinment Date</label>
              <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" required>
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button class="btn btn-primary" type="submit">Request</button>
          </div>
        </div>
    </form>
    </div>
  </div>
</div>
<script>
 $(document).ready(function () {
    $("#exampleModal").on("show.bs.modal", function (e) {
        var id = $(e.relatedTarget).data('id');
        $('#batchId').val(id);
        var centre = $(e.relatedTarget).data('centre');
        $('#centre').val(centre);
    });
    // $("#exampleModal").on("show.bs.modal", function (e) {
    //     var expiry = $(e.relatedTarget).data('expiry');
    //     // $("#appointmentDate").attr({
    //     //     "max" : "10-11-2021"
    //     // });
    //     document.getElementById("appointmentDate").setAttribute("max", expiry);
    // }
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kerja\SE RAM\PCVS\resources\views/vaccination/index.blade.php ENDPATH**/ ?>