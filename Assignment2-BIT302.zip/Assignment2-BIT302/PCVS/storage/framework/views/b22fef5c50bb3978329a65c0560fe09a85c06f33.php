
<script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js"></script>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class=" justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom text-center">
            <h2>Vaccine Batch </h2>
            <small > <strong><?php echo e($centre->centreName); ?></strong>, <?php echo e($centre->address); ?></small>
        </div>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success fade show" role="alert">
            <?php echo e(session('success')); ?>

        </div>
            
        <?php elseif(session()->has('rejected')): ?>
        <div class="alert alert-danger fade show" role="alert">
            <?php echo e(session('rejected')); ?>

        </div>
            
        <?php endif; ?>
        <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger fade show" role="alert">
            <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
        <div class="table-responsive">
            <h2 class="text-center">List of Vaccionation Appointment</h2>
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Appointment ID</th>                    
                    <th scope="col">Patient IC</th>                    
                    <th scope="col">Patient Name</th>                    
                    <th scope="col">Batch Number</th>                    
                    <th scope="col">Vaccine Name</th>
                    <th scope="col">Manufacture</th>
                    <th scope="col">Appointment Date</th>                    
                    <th scope="col">Expire Date</th>
                    <th scope="col">Remarks</th>
                    <th scope="col">Status </th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $vaccination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($patient->find($item->patientId)->ic); ?></td>
                        <td><?php echo e($patient->find($item->patientId)->name); ?></td>
                        <td><?php echo e($data_batch->find($item->batchId)->batchNo); ?></td>
                        <td><?php echo e($vaccine->find($data_batch->find($item->batchId)->vaccineId)->name); ?></td>
                        <td><?php echo e($vaccine->find($data_batch->find($item->batchId)->vaccineId)->manufacture); ?></td>
                        <td><?php echo e($item->appointmentDate); ?></td>
                        <td><?php echo e($data_batch->find($item->batchId)->expiryDate); ?></td>
                        <td><?php echo e($item->remarks); ?></td>
                        <?php if($item->status == "Confirmed"): ?>
                            <td class="text-success"><?php echo e($item->status); ?></td>
                            
                        <?php elseif($item->status == "Rejected"): ?>
                            <td class="text-danger"><?php echo e($item->status); ?></td>

                        <?php else: ?>
                            <td class="text-primary"><?php echo e($item->status); ?></td>
                            
                        <?php endif; ?>
                        <?php if($item->status == "Confirmed"): ?>
                            <td><button class="btn btn-primary btn-sm"  data-bs-toggle="modal" data-batch-id="<?php echo e($item->batchId); ?>" data-id="<?php echo e($item->id); ?>" data-status="<?php echo e($item->status); ?>" data-bs-target="#administered">Administered</button> </td>
    
                        <?php elseif($item->status == "Rejected"): ?>
                            <td> Rejected</td>
                        <?php else: ?>
                            <td>
                                <button class="btn btn-success btn-sm"  data-bs-toggle="modal" data-batch-id="<?php echo e($item->batchId); ?>" data-id="<?php echo e($item->id); ?>" data-status="<?php echo e($item->status); ?>" data-date="<?php echo e($item->appointmentDate); ?>" data-bs-target="#confirm">Confirm</button> 
                                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-batch-id-r="<?php echo e($item->batchId); ?>" data-id-r="<?php echo e($item->id); ?>" data-status-r="<?php echo e($item->status); ?>" data-bs-target="#reject">Reject</button>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
        </main>
    </div>
</div>
</div>

<!-- Modal Confirm -->
<div class="modal fade" id="confirm" tabindex="-1" aria-labelledby="confirmLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-light">
                <h5 class="modal-title" id="exampleModalLabel">Confirm Appointment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="/confirm" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input type="hidden" class="form-control" id="vaccinationId" name="vaccinationId" value="">
                        <input type="hidden" class="form-control" id="batchId" name="batchId" value="">
                    </div>
                    <div class="mb-3">
                        <label for="vaccine" class="form-label">Appointment Date</label>
                        <input type="text" class="form-control" id="appointmentDate" name="appointmentDate" value="" disabled>
                        <input type="hidden" class="form-control" id="status" name="status" value="Confirm" disabled>
                    </div>
                    <div class="mb-3">
                        <label for="remark" class="form-label">Remark</label>
                        <input type="text" class="form-control" id="remark" name="remark" >
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button class="btn btn-success" type="submit">Confirm The Appointment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
 <!-- Modal reject -->
 <div class="modal fade" id="reject" tabindex="-1" aria-labelledby="rejectLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-light">
            <h5 class="modal-title" id="exampleModalLabel">Reject Appointment</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="/reject" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input type="hidden" class="form-control" id="vaccinationIdR" name="vaccinationId" value="">
                        <input type="hidden" class="form-control" id="batchIdR" name="batchId" value="">
                        <input type="hidden" class="form-control" id="status" name="status" value="Rejected" disabled>
                    </div>
                    <div class="mb-0">
                        <label for="remark" class="form-label">Remark</label>
                        <input type="text" class="form-control" id="remark" name="remark" >
                    </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-danger" type="submit">Reject The Appointment</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

 

<script>
$(document).ready(function () {
    $("#confirm").on("show.bs.modal", function (e) {
        var id = $(e.relatedTarget).data('id');
        var status = $(e.relatedTarget).data('status');
        var batch = $(e.relatedTarget).data('batch-id');
        var date = $(e.relatedTarget).data('date');
        $('#batchId').val(batch);
        $('#statusC').val(status);
        $('#appointmentDate').val(date);
        $('#vaccinationId').val(id);
    });
    $("#reject").on("show.bs.modal", function (a) {
        var id = $(a.relatedTarget).data('id-r');
        var status = $(a.relatedTarget).data('status-r');
        var batch = $(a.relatedTarget).data('batch-id-r');
        $('#batchIdR').val(batch);
        $('#statusCR').val(status);
        $('#vaccinationIdR').val(id);
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kerja\SE RAM\PCVS\resources\views/vaccination/detail.blade.php ENDPATH**/ ?>