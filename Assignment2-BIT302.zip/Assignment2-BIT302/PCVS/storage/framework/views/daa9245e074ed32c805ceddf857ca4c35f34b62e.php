<?php echo e($slot); ?>

<?php /**PATH F:\Kerja\SE RAM\PCVS\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>